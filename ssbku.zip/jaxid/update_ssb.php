<?php
include "koneksi.php";

$id_club       = $_POST['id_club'];
$nama_club = $_POST['nama_club'];
$pelatih = $_POST['pelatih'];
$alamat = $_POST['alamat_club'];
$jadwal_hari = $_POST['jadwal_hari'];
$jadwal_jam = $_POST['jadwal_jam'];

$query = mysqli_query($koneksi, "UPDATE club SET nama_club='$nama_club', pelatih='$pelatih', alamat_club='$alamat', jadwal_hari='$jadwal_hari', jadwal_jam='$jadwal_jam' WHERE id_club='$user_id'")or die(mysql_error());
if ($query){
header('location:anggota.php');	
} else {
	echo "gagal Update";
    }
?>

